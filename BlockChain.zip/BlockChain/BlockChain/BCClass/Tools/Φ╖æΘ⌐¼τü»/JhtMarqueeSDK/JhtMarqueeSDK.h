//
//  JhtMarqueeSDK.h
//  JhtMarqueeSDK
//
//  GitHub主页: https://github.com/jinht
//  CSDN博客: http://blog.csdn.net/anticipate91
//
//  Created by Jht on 16/8/29.
//  Copyright © 2016年 Jht. All rights reserved.
//

#import <Foundation/Foundation.h>


#import "JhtVerticalMarquee.h"
#import "JhtHorizontalMarquee.h"
