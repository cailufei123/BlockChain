//
//  LKControllerTool.h
//  Likein
//
//  Created by 蔡路飞 on 16/7/10.
//  Copyright © 2016年 leshigames. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LKControllerTool : NSObject
/**
 *  选择根控制器
 */
+ (void)chooseRootViewController;
@end
