//
//  BCCodeAlertView.h
//  BlockChain
//
//  Created by 蔡路飞 on 2018/5/23.
//  Copyright © 2018年 蔡路飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BCCodeAlertView : UIView

+(instancetype)loadNameBCCodeAlertViewXib ;
@end
