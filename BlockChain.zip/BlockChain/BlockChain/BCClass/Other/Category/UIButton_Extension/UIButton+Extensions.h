//
//  UIButton+Extensions.h
//  BodyIntellect1.2
//
//  Created by 李静波 on 16/11/3.
//  Copyright © 2016年 知子花. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Extensions)

@property(nonatomic, assign) UIEdgeInsets hitEdgeInsets;

@end
