//
//  UITextField+WBTextField.h
//  BlockChain
//
//  Created by Mac on 2018/6/4.
//  Copyright © 2018年 蔡路飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (WBTextField)



/**
 *  报告界面专用label
 */
//+ (instancetype)reportNormalLabelWithFrame:(CGRect)frame text:(NSString *)text font:(CGFloat)font;

@end
