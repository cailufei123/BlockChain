//
//  YWCustomMessageCell.m
//  PunchTopMasters
//
//  Created by 蔡路飞 on 2018/3/10.
//  Copyright © 2018年 蔡路飞. All rights reserved.
//

#import "YWCustomMessageCell.h"

@implementation YWCustomMessageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
