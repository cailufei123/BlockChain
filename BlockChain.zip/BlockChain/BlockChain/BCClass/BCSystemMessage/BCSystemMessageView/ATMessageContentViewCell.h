//
//  ATMessageContentViewCell.h
//  Auction
//
//  Created by 蔡路飞 on 2017/11/9.
//  Copyright © 2017年 Cailufei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATMessageContentViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLb;
@end
