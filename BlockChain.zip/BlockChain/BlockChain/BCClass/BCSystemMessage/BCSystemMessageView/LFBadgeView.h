//
//  HMBadgeView.h
//  黑马微博
//
//  Created by apple on 14-7-21.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LFBadgeView : UIButton
/** 提醒数字 */
@property (nonatomic, copy) NSString *badgeValue;
@end
