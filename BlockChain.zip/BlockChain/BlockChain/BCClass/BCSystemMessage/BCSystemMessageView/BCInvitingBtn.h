//
//  BCInvitingBtn.h
//  BlockChain
//
//  Created by Mac on 2018/5/27.
//  Copyright © 2018年 蔡路飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BCInvitingBtn : UIButton

@end
