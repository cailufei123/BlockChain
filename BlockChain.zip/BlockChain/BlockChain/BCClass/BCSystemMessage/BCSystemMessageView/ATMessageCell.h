//
//  ATMessageCell.h
//  Auction
//
//  Created by 蔡路飞 on 2017/11/9.
//  Copyright © 2017年 Cailufei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMessageModel.h"
@interface ATMessageCell : UITableViewCell
@property (strong, nonatomic)SAMessageModel * messageModel;
@end
