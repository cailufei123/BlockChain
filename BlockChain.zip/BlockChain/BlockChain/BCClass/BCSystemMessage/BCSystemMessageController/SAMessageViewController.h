//
//  SAMessageViewController.h
//  SkinAssistant
//
//  Created by 蔡路飞 on 2017/6/28.
//  Copyright © 2017年 LeGame. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SAMessageViewController : UIViewController

@end
