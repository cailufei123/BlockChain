//
//  BCMeInvitingFriendsModel.m
//  BlockChain
//
//  Created by Mac on 2018/5/26.
//  Copyright © 2018年 蔡路飞. All rights reserved.
//

#import "BCMeInvitingFriendsModel.h"

@implementation BCMeInvitingFriendsModel

@end
