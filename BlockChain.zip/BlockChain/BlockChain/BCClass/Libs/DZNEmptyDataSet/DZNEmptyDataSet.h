//
//  DZNEmptyDataSet.h
//  DZNEmptyDataSet
//
//  Created by Ignacio Romero on 2/28/17.
//  Copyright © 2017 DZN. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DZNEmptyDataSet.
FOUNDATION_EXPORT double DZNEmptyDataSetVersionNumber;

//! Project version string for DZNEmptyDataSet.
FOUNDATION_EXPORT const unsigned char DZNEmptyDataSetVersionString[];

#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
