//
//  EnvExport.h
//  SecurityEnvTest
//
//  Created by asherli on 17/9/1.
//  Copyright © 2017年 alibaba. All rights reserved.
//

#ifndef EnvExport_h
#define EnvExport_h

#define SEC_ERROR_UMID_OK  0
#define SEC_ERROR_UMID_UNKNOWN_ERR 1

#endif /* EnvExport_h */
