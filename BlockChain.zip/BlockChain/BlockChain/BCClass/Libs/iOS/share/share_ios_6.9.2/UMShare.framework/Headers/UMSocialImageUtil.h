//
//  UMSocialImageUtil.h
//  UMSocialSDK
//
//  Created by wangfei on 16/8/12.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface UMSocialImageUtil : NSObject
+(UIImage*)scaleImage:(UIImage *) image ToSize:(CGSize)size;
@end
